package Group_Project;

public class Card {

}
